package com.company.users;

public class Customer extends User{

    private int money;
  //  private int id;

    public Customer(String fname, String lname, int age, int gender,int money){
        super(fname, lname, age, gender);
        this.money = money;
    }


    public String toString(){
        String str = "\nFull name:"+super.getF_Name()+" "+super.getL_Name()+", Age: "+super.getAge()+", ";
        if(super.getGender() == 1){
            str += "Male";
        }else if(super.getGender() == 0){
            str += "Female";
        }
        str += ", CASH: " + money;
        return str;
        //return "\nFull name:"+f_Name+" "+l_Name+", Age: "+age+", gender(1 male,0 female) "+gender+if(gender == 1)"male";
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
}
